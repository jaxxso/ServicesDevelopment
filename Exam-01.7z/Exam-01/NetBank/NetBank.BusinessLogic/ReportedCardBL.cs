﻿using NetBank.DataAccess;
using NetBank.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NetBank.BusinessLogic
{
    class ReportedCardBL
    {
        private readonly ReportedCardDA _reportedCardDA;

        public ReportedCardBL(ReportedCardDA reportedCardDA)
        {
            _reportedCardDA = reportedCardDA;
        }

        public async Task<IList<Models.ReportedCard>> GetAllReportedCards()
        {
            return await _reportedCardDA.GetAllReportedCards();

        }
        public async Task<IList<Models.ReportedCard>> GetAllReportedCardsByIssuingNetworkName(string issuingIssuingNetworkName)
        {
            return await _reportedCardDA.GetAllReportedCardsByIssuingNetworkName(issuingIssuingNetworkName);

        }
        public async Task<Models.ReportedCard> GetReportedCard(string CreditCardNumber)
        {
            if (CreditCardBL.IsValid(CreditCardNumber))
            {
                return await _reportedCardDA.GetReportedCard(CreditCardNumber);
            }
            return null;
        }

        public async Task<string> PutCreditCardReactivated(string CreditCardNumber)
        {
            if (CreditCardBL.IsValid(CreditCardNumber))
            {
                return await _reportedCardDA.PutCreditCardReactivated(CreditCardNumber);
            }
            return "Credit Card Recovered";

        }

    }
}
