﻿using System;
using System.ComponentModel.DataAnnotations;

namespace NetBank.Models
{
    public class ReportedCard
    {
        [Key]
        public int Id { get; set; }

        [Required]
        public string IssuingNetwork { get; set; }

        [Required]
        public string CreditCardNumber { get; set; }

        public string FirstName { get; set; }

        public string LastName { get; set; }

        [Required]
        public string StatusCard { get; set; }
        
        [Required]
        public DateTime ReportedDate { get; set; }

        [Required]
        public DateTime LastUpdatedDate { get; set; }

    }
}

