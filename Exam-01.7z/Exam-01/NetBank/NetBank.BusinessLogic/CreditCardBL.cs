﻿using System;
using System.Linq;
using System.Text;

namespace NetBank.BusinessLogic
{
    public static class CreditCardBL
    {
        public static bool IsValid(string creditCardNumber)
        {
            var digitsOnly = GetDigits(creditCardNumber);
            int sum = 0;
            int digit = 0;
            int addend = 0;
            bool timesTwo = false;
            const int maxValueDigit = 9;
            const int minLength = 13;
            const int maxLength = 19;

            if (digitsOnly.Length > maxLength || digitsOnly.Length < minLength) return false;

            for (var i = digitsOnly.Length - 1; i >= 0; i--)
            {
                digit = int.Parse(digitsOnly.ToString(i, 1));
                if (timesTwo)
                {
                    addend = digit * 2;
                    if (addend > maxValueDigit)
                        addend -= maxValueDigit;
                }
                else
                    addend = digit;

                sum += addend;

                timesTwo = !timesTwo;

            }
            return (sum % 10) == 0;
        }
        private static StringBuilder GetDigits(string creditCardNumber)
        {
            var digitsOnly = new StringBuilder();
            foreach (var character in creditCardNumber)
            {
                if (char.IsDigit(character))
                    digitsOnly.Append(character);
            }
            return digitsOnly;
        }
    }

}
